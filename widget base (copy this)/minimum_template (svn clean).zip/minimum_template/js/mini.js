
minimumTemplateWidget = {
    
    pageContentDivClass: 'minimum_main_content',
    contentDivClass: 'minimum_content',
    
    widgetTitle: 'minimumTemplate',
    widgetName: 'minimum_template', // also name of folder
    
    // function that will be called upon start (REQUIRED - do NOT change the name)
    open: function(project_widget_id, widgetIconId, last_position) {
    
        var windowOptions = {
             title: minimumTemplateWidget.widgetTitle,
             width: 300,
             height: 200,
             x: 10,
             y: 15,
             content: minimumTemplateWidget.getInitialContent()
         };

        Desktop.newWidgetWindow(project_widget_id, windowOptions, widgetIconId, minimumTemplateWidget.partialContentDivClass, last_position);
        
    },
    
    // set content in widgets div, called from the ajax request
   setContent: function(data) {
        // The success return function, the data must be unescaped befor use.
        // This is due to ILLEGAL chars in the string.    
        Desktop.setWidgetContent(unescape(data));
    },
    
    
    // ----------------------------------------------------------------------------------------------------------------------
                     
    getInitialContent: function() {
        return '<h1>Initial content</h1><p>Lorem ipsum hejsan hoppsan kalle kule var här och skrev lite grann....</p>';    
    }   
    
}
