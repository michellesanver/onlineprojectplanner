<?php

class theModel extends Model {

    function __construct()
    {
        parent::Model();
    }
    
}