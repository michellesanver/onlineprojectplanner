/* 
* Name: 
* Desc: 
* Last update: 
*/
function name(id, wnd_options) {
	this.widgetName = "";
	this.title = "";
	var partialClasses = [''];
	
	// set options for window
	wnd_options.title = this.title;
	wnd_options.allowSettings = true;
	wnd_options.width = 800;
	wnd_options.height = 450;
	
	// Add settings event listener
	//Desktop.settingsEvent.addSettingsEventListener(id, "settingsEventTest");
	
	this.create(id, wnd_options, partialClasses);
}

ajaxTemplateWidget.Inherits(Widget);

/*
* Here comes all happening function. Executed from html links
* 
*/
// Overwriting the index function!
ajaxTemplateWidget.prototype.index = function() {
	//MUST BE IMPLEMENTED
}

/*
// Eventcatcher. Catches the new settingsdata
ajaxTemplateWidget.prototype.settingsEventTest = function(data) {
	alert($.dump(data));
}
*/